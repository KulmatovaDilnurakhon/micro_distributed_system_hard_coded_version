package com.example.FlashCardFuns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlashCardFunsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlashCardFunsApplication.class, args);
	}

}
