package com.example.PeopleManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeopleManager {

	public static void main(String[] args) {
		SpringApplication.run(PeopleManager.class, args);
	}

}
