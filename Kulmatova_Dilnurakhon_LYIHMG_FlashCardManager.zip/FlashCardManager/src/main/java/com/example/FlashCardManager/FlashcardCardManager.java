package com.example.FlashCardManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlashcardCardManager {

	public static void main(String[] args) {
		SpringApplication.run(FlashcardCardManager.class, args);
	}

}
